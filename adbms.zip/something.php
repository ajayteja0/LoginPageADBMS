<?php 
	
        $dbhost = 'localhost';
        $dbuser = 'ajay';
        $dbpass = '';
        $dbname = 'demo';
		
		
		$username = $_POST["accountno"];
		$balance = $_POST["balance"];
		$tranfer_value = $_POST["tranfer_value"];
		$tranfer_to = $_POST["tranfer_to"]; 		
		//echo $username;
		
		if($tranfer_value>$balance)
		{
			echo "Transfer amount cannot exceed " . $balance;
		}
		else
		{
			$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);	
			if($conn->connect_errno) 
			{
			printf("Connect failed: %s<br />", $mysqli->connect_error);
			exit();
			}
			$some = "UPDATE users set balance = balance - ".$tranfer_value." where username = ". $username;
			$some2 = "UPDATE users set balance = balance + ".$tranfer_value. " where username = ".$tranfer_to;
			echo "Transfer Successfull\n";
			$result = $conn->query($some);
			$result = $conn->query($some2);
			echo "LEt us see";
			
		}
		
?>